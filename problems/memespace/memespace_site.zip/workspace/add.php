<?php

//die('<p><b>Sorry! Adding memes is disabled right now!</b></p><a href="/">Back</a>');

include('hash.php');
$name = $_POST[name];
$password = $_POST[password];
$password = myhash($password);

$target_dir = "./uploads/";
$target_file = $target_dir . basename($_FILES["meme"]["name"]);

$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

$target_file = $target_dir . $password . "." . $imageFileType;

$allowedTypes = array(IMAGETYPE_PNG, IMAGETYPE_JPEG, IMAGETYPE_GIF);
$detectedType = exif_imagetype($_FILES['meme']['tmp_name']);
$error = !in_array($detectedType, $allowedTypes);
if($error) {
    die($error);
}

// Check if file already exists
if (file_exists($target_file)) {
    die("ERROR: that file already exists");
}

// Check file size > 100kb
if ($_FILES["meme"]["size"] > 100000) {
    die("ERROR: File is too large");
}

if ($name=="" || $password=="" || strlen($name)>32 || strlen($target_dir)>150) {
    die("ERROR: invalid name or password");
} else { 
    $db_servername = "localhost";
    $db_username = "memespace";
    $db_password = "n1ce_m3m3!";
    $db_database = "web_problems";
    
    // Create connection
    $conn = new mysqli($db_servername, $db_username, $db_password, $db_database);
    
    if (!$conn ) {
        die( 'ERROR: '.mysqli_connect_error() );
    }
    if ($conn->connect_error) {
        die("ERROR: MYSQL connection failed. Report this to an admin!");
    } 
    
    $stmt = mysqli_prepare($conn,"INSERT INTO memespace (name, password, imagepath) VALUES (?, ?, ?)");
    if (!$stmt) {
        die('ERROR : '.mysqli_error($conn));
    }

    mysqli_stmt_bind_param($stmt,"sss", $name, $password, $target_file);
    mysqli_stmt_execute($stmt);

    mysqli_stmt_close($stmt);
    mysqli_close($conn);
    
    echo $_FILES["meme"]["tmp_name"];
    echo $target_file;
    
    if (move_uploaded_file($_FILES["meme"]["tmp_name"], $target_file)) {
        echo "<p>The file has been uploaded.</p>";
        echo '<a href="/">Go back to the main page</a>';
    } else {
        die("ERROR: Sorry, there was an error uploading your file.");
    }
}
?>