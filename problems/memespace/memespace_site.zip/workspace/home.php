<div class="jumbotron">
  <div class="container">
    <h1>MemeSpace</h1>
    <p>A site to store and password protect ur dank memes!!!!!!1!!1!</p>
    <img src="/images/trump.jpeg"></img>
    <p><a class="btn btn-primary btn-lg" href="/index.php?page=list" role="button">GO!! -></a></p>
  </div>
</div>