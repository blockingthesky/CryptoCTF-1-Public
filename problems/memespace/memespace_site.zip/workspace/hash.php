<?php
function myhash($string)
{
    $result = "0";
    $l = strlen($string);
    for ($x = 0; $x <= $l; $x++) {
        $term = bcmod(bcmul("256", bcpow( (string)(ord($string[$x])), (string)($l-$x))), "1000000000000000000000000000000");
        $result = bcadd($result, $term);
    }
    return $result;
}
?>
