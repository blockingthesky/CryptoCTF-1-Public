<?php
$servername = "localhost";
$username = "memespace";
$password = "n1ce_m3m3!";
$database = "web_problems";

// Create connection
$conn = new mysqli($servername, $username, $password,$database);

// Check connection
if ($conn->connect_error) {
    die("ERROR: MYSQL connection failed. Report this to an admin!");
}


if ($result = mysqli_query($conn, "SELECT * FROM memespace")) {
    $numrows = mysqli_num_rows($result);
    echo $numrows." memes are currently available!</br>";
  
    if($numrows>0) {
        echo '<table class="table">';
        echo '<thead>
                  <tr>
                    <th>Meme Name</th>
                    <th>View</th>
                  </tr>
                </thead><tbody>';
        while($row = mysqli_fetch_array($result)) {
            echo '<tr>';
           echo "<td>".htmlentities($row['name'])."</td>";
           echo '<td><form class="form-inline" role="form" action="/viewmeme.php" method="post">
  <div class="form-group">
    <input type="hidden" name="name" value="'.htmlentities($row['name']).'">
    <label for="password">Enter Password:</label>
    <input type="password" class="form-control" id="password" name="password">
  </div>
  <button type="submit" class="btn btn-success">View</button>
</form></td></tr>';
        }
        echo '</tbody></table>';
    }
    
    /* free result set */
    mysqli_free_result($result);
    mysqli_close($conn);
}
?>