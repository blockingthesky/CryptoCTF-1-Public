<?php

include('hash.php');
$name = $_POST[name];
$password = $_POST[password];
$password = myhash($password);

if ($name=="" || $password=="" || strlen($name)>32) {
    die('<p><b>Invalid name or password!</b></p><a href="/index.php?page=list"> Go Back </a>');
} else { 
    $db_servername = "localhost";
    $db_username = "memespace";
    $db_password = "n1ce_m3m3!";
    $db_database = "web_problems";
    
    // Create connection
    $conn = new mysqli($db_servername, $db_username, $db_password,$db_database);
    
    // Check connection
    if ($conn->connect_error) {
        die("ERROR: MYSQL connection failed. Report this to an admin");
    }
    
    
    if ($result = mysqli_query($conn, "SELECT * FROM memespace WHERE name='".$name."' AND password='".$password."'")) {
        $numrows = mysqli_num_rows($result);
        if($numrows>0) {
            while($row = mysqli_fetch_array($result)) {
                echo "<img src='".$row['imagepath']."'></img>";
            }
            echo '</br><a href="/index.php?page=list"> Go Back </a>';
        }
        else {
            echo '<p><b>Invalid password!</b></p></br><a href="/index.php?page=list"> Go Back </a>';
        }
        
        mysqli_free_result($result);
    }
    mysqli_close($conn);
} 

?>